import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { responseName } from './response.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'figma-to-code-frontend';

  fileId: any;
  token: any;
  folderName: string | undefined;
  folderGeneName: string | undefined;

  constructor(private http: HttpClient) {}

  async generateDesignToCode(): Promise<string> {
    const body = {
      fileId: this.fileId,
      token: this.token,
    };

    const res = await this.http
      .post<any>('http://localhost:3000', body)
      .pipe(
        map((res) => {
          this.folderName = res.fileName;
          this.folderGeneName = res.folderGeneName;
          return res.folderName;
        })
      )
      .toPromise();
    return res || '';
  }

  // async download() {
  //   this.http
  //     .get('http://localhost:3000/download', { responseType: 'blob' })
  //     .pipe(
  //       map((data) => {
  //         const blob = new Blob([data], { type: 'application/zip' });
  //         const url = window.URL.createObjectURL(blob);
  //         const a = document.createElement('a');
  //         a.href = url;
  //         a.download = this.folderName as string;
  //         a.click();
  //         window.URL.revokeObjectURL(url);
  //         return this.folderName;
  //       })
  //     )
  //     .toPromise();
  // }

  async downloadAndDelete(generated: string) {
    try {
      console.log(generated)
      const response: any = await this.http
        .get(`http://localhost:3000/download?folder=${generated}`, {
          responseType: 'blob',
        })
        .toPromise();

      if (response) {
        console.log(response)
        const blob = new Blob([response], { type: 'application/zip' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = this.folderGeneName?.substring(17,this.folderGeneName.length ) || '';
        a.click();
        window.URL.revokeObjectURL(url);
      
        await this.deleteFile();
      } else {
        console.error('HTTP response is undefined');
      }
    } catch (error) {
      console.error('Error downloading file:', error);
      // Handle errors as needed
    }
  }

  deleteFile() {
    this.http
      .delete(
        `http://localhost:3000/delete?folderGeneName=${this.folderGeneName}&folderName=${this.folderName}`
      )
      .subscribe((res) => {
        console.log(res);
      });
  }

  async generate() {
    const generated = await this.generateDesignToCode();
    console.log(this.folderGeneName, this.folderName);
    await this.downloadAndDelete(this.folderName || '');
    // console.log('done');
  }
}
