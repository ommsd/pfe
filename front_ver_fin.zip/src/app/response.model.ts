export interface responseName {
    folderName: string
}