import { Token } from 'src/types/FigmaParser.models';

export const defaultTokens: Token[] = [
  'iconbtn',
  'vgprogressbar',
  'group',
  'label',
  'comboBox',
  'colors',
  'date',
  'btnLink',
  'name',
  'featureName',
  'title',
  'template',
  'textfiled',
  'textarea',
  'button',
  'radioBtn',
];

export const figmaApiBasePath = 'https://api.figma.com/v1/';

export const tokensToExtract: Token[] = [
  'vgprogressbar',
  'label',
  'comboBox',
  'template',
  'title',
  'name',
  'featureName',
  'textfiled',
  'button',
  'textarea',
  'radioBtn',
  'btnLink',
  'date',
];

export const generationFolderName = 'generationFolder';
