import { generateUniqueName } from "./utilities"
//Screen general information
export const screenTemplate = (screenFeatureName, screenTemplateName) => ({
	name: "",
	featureName: screenFeatureName,
	title: "",
	showTitle: false,
	template: screenTemplateName,
	componentsBreakpoints: {
		xs: 12,
		sm: 12,
		md: 6,
		lg: 4,
	},
	unlinked: true,
	actions: [],
	columns: [],
	components: [],
})
// custom comp information

// icon btn 
export const iconButtonTemplate = ( iconName, styleName? , breakpoints?) => ({
	type: "Button",
      properties: {
        label: "",
		styleName,
		horizontalAlignment: "left",
        verticalAlignment: "none",
        iconDirection: "left",
        visibleCondition: {
          hideColumn: false
        },
		template: "empty",
        additionalAttributes: [
          {
            type: "static"
          }
        ],
		exportedKeys: "ALL",
        exportedItems: "Selected",
        exportFormat: "Default",
        showExportOptions: true,
        isRequiredRoleName: false,
        icon: iconName,
      },
	  breakpoints,
        
      name: "Button" + generateUniqueName()
})
// textfilter information
export const textFilterTemplate= ( textFilterName, styleName?, breakpoints?) =>({
	type: textFilterName,
      properties: {
        label: "",
		styleName,
		verticalAlignment: "none",
        defaultOperator: "~",
        minimumCharacters: 3,
        additionalAttributes: [
          {
            type: "static"
          }
        ]
	},
	showLabel: false,
	breakpoints,
	  
	name: textFilterName + generateUniqueName(),
})
// searchable information 
export const searchableTemplate = (searchableName , searchableLabel , styleName ?, breakpoints?)=> ({
	type: searchableName,
	properties: {
		label: searchableLabel,
		styleName,
        navigationType: "dialog",
        visibleCondition: {
          hideColumn: false
        },
		showLabel: false,
        showCheckBoxOnRow: false,
		additionalAttributes: [
			{
			  type: "static"
			}
		  ],
		  feature: "",
        screen: "",
        roleName: "",
        placeholder: ""
      },
	  breakpoints,
        
      
	  name: searchableName + generateUniqueName()

})
// line information
export const lineTemplate=(lineName , styleName? ) => ({
	type: lineName,
      properties: {
		styleName,
        hideOperator: true
      },
	  breakpoints: {
        "xs": 12,
        "sm": 12,
        "md": 6,
        "lg": 11,
        "row": 2,
        "col": 0,
        "height": 1
      },
	  name: lineName + generateUniqueName()
})
// vg-progress-bar(custom)
export const vgprogressbartemplate=(selectorType) =>({
	type: "CustomComponent",
	properties: {
        closeTag: false,
		visibleCondition: {
			hideColumn: false
		  },
		  selector: selectorType,
        attributes: [
			{
				name: "className",
				type: "static"
			  },
			  {
				name: "data",
				type: "static",
				
			  },
			  {
				name: "progressBarPosition",
				type: "static"
			  },
			  {
				name: "progressValuesKey",
				type: "static"
			  },
			  {
				name: "showProgress",
				type: "static"
			  },
			  {
				name: "showTitle",
				type: "static"
			  },
			  {
				name: "showTotal",
				type: "static"
			  },
			  {
				name: "sumMode",
				type: "static"
			  },
			  {
				name: "title",
				type: "static"
			  },
			  {
				name: "totalKey",
				type: "static",
			  }
			],
			events: [
			  {
				type: "custom"
			  }
			]
		  },
		  breakpoints: {
			"col": 2,
			"md": 6,
			"sm": 12,
			"xs": 12,
			"lg": 4,
			"row": 1,
			"height": 1
		  },
		  name: "CustomComponent" + generateUniqueName(),

})
// label information 
export const labelTemplate= (labelName , labelLabel, styleName , breakpoints?) => ({
	type: labelName,
	properties: {
        label: labelLabel ,
		styleName,
        FractionDigits: false,
        staticFormatting: false,
        symbolPosition: "left",
        currencyFormatter: false,
        alignment: "left",
        iconDirection: "left",
        visibleCondition: {
          hideColumn: false
        },
		additionalAttributes: [
			{
			  type: "static"
			}
		  ]
		},
		breakpoints,
		name : labelName+ generateUniqueName()
})
// comboBox information 
export const comboBoxTemplate = (comboBoxType,comboBoxName,styleName,breakpoints?) =>({
	type: comboBoxType,
	properties: {
	  label: comboBoxName,
	  styleName,
	  defaultOperator: "==",
	  enableSorting: false,
	  showLabel: true,
	  possibleValuesService: {
		headerObject: true
	  },	  
	  visibleCondition: {
		hideColumn: false
	  },
	  displayFilter: true,
	  lazy: true,
	  additionalAttributes: [
		{
		  type: "static"
		}
	],
	getDataFrom: "webServices",
	sortBy: "asc",
	hideOperator: true
},
	breakpoints,
	name: comboBoxType + generateUniqueName()
})
// section information

export const sectionTemplate = (sectionType, styleName?,breakpoints?) => ({
	type: sectionType,
	parentBlockId :null,
	properties: {
		styleName,
		additionalAttributes: [
			{
				type: "static",
			},
		],
		visibleCondition: {
			hideColumn: false,
		},
	},
	breakpoints,
	
	
	componentsBreakpoints: {
		xs: 12,
		sm: 12,
		md: 6,
		lg: 4,
	},
	name: sectionType + generateUniqueName(),
	components: [],
})
// group information
export const groupTemplate = (groupType,groupLabel,styleName ?, breakpoints?) => ({
	type: groupType,
	properties: {
		label: groupLabel,
		styleName,
		showLabel: false,
		additionalAttributes: [
			{
				type: "static",
			},
		],
		visibleCondition: {
			hideColumn: false,
		},
		collapsible: true,
	},
	breakpoints,
	
	componentsBreakpoints: {
		xs: 12,
		sm: 12,
		md: 6,
		lg: 4,
	},
	name: groupType + generateUniqueName(),
	components: [],
})

// ButtonLink information
export const linkBtnTemplate = (btnLinkName, btnLinkLabel) => {
	return {
		type: btnLinkName,
		properties: {
			label: btnLinkLabel,
			iconDirection: "left",
			visibleCondition: {
				hiddenColumn: false,
			},
			additionalAttributes: [
				{
					type: "static",
				},
			],
		},
		breakpoints: {
			xs: 12,
			sm: 12,
			md: 6,
			lg: 5,
			row: 1,
			col: 2,
			height: 1,
		},
		name: btnLinkName + generateUniqueName(),
	}
}
// textArea information
export const textAreaTemplate = (textAreaName, textAreaLabel) => ({
	type: textAreaName,
	properties: {
		label: textAreaLabel,
		defaultOperator: "==",
		showLabel: true,
		rows: 3,
		visibleCondition: {
			hideColumn: false,
		},
		additionalAttributes: [
			{
				type: "static",
			},
		],
	},
	breakpoints: {
		xs: 12,
		sm: 12,
		md: 6,
		lg: 3,
		row: 1,
		col: 3,
		height: 1,
	},
	name: textAreaName + generateUniqueName(),
})
// date information
export const dateTemplate = (dateName, dateLabel, breakpoints) => ({
	type: dateName,
	properties: {
		label: dateLabel,
		defaultOperator: "==",
		visibleCondition: {
			hideColumn: false,
		},
		showLabel: true,
		additionalAttributes: [
			{
				type: "static",
			},
		],
	},
	breakpoints,
		
	name: dateName + generateUniqueName(),
})

// radioBtn information
export const radioBtnTemplate = (radioBtnName, radioBtnLabel) => ({
	type: radioBtnName,
	properties: {
		label: radioBtnLabel,
		defaultOperator: "==",
		showLabel: true,
		visibleCondition: {
			hideColumn: false,
		},
		additionalAttributes: [
			{
				type: "static",
			},
		],
	},
	breakpoints: {
		xs: 12,
		sm: 12,
		md: 6,
		lg: 4,
		row: 0,
		col: 7,
		height: 1,
	},
	name: radioBtnName + generateUniqueName(),
})
// textFiled information
export const textFieldTemplate = (textFieldName, textFiledLabel) => ({
	type: textFieldName,
	properties: {
		label: textFiledLabel,
		visibleCondition: {
			hideColumn: false,
		},
		showLabel: true,
		defaultOperator: "==",
		additionalAttributes: [
			{
				type: "static",
			},
		],
	},
	breakpoints: {
		xs: 12,
		sm: 12,
		md: 6,
		lg: 4,
		row: 2,
		col: 3,
		height: 1,
	},
	name: textFieldName + generateUniqueName(),
})
// btn information
export const btnTemplate = (btnName, btnLabel , styleName , breakpoints?) => ({
	type: btnName,
	properties: {
		label: btnLabel,
		styleName,
		horizontalAlignment: "left",
		verticalAlignment: "none",
		iconDirection: "left",
		visibleCondition: {
			hiddenColumn: false,
		},
		template: "empty",
		additionalAttributes: [
			{
				type: "static",
			},
		],
		showExportOptions: true,
		exportedKeys: "ALL",
		exportedItems: "Selected",
		exportFormat: "Default",
		isRequiredRoleName: false,
	},
		breakpoints,
	name: btnName + generateUniqueName(),
})
// 
export const customCompTemplate = (breakpoints, name: string)=>({
	type: "CustomComponent",
	properties: {
	  selector: "div",
	  attributes: [
		{
		  type: "static"
		}
	  ],
	  visibleCondition: {
		hideColumn: false
	  },
	  events: [
		{
		  type: "custom"
		}
	  ]
	},
	breakpoints,
	name
  
		
})
// css 
export const getStyles = ({ styleName, background, color, fontweight, fontsize, borderradius  }:
	{ styleName: string; background?: string; color?: string; fontweight?: string; fontsize?: string; borderradius?: string;}) =>
	`.${styleName} {
	${background ? `background-color: ${background}` : ""}
	${color ? `color: ${color}` : ""}
	${fontweight ? `font-weight: ${fontweight}` : ""}
	${fontsize ? `font-size: ${fontsize}` : ""}
	${borderradius ? `border-radius:${borderradius}` : ""}
	
	
}`
