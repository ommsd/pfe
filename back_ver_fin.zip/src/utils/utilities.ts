export function generateUniqueName() {
  return `${Math.floor(Math.random() * 90000) + 10000}`;
}

export function multiplyColor(color) {
  const multipliedColor = {
    r: Math.round(color.r * 255),
    g: Math.round(color.g * 255),
    b: Math.round(color.b * 255),
  };
  return `rgb(${multipliedColor.r}, ${multipliedColor.g}, ${multipliedColor.b})`;
}

export function convertToBreakpoints(
  x: number, w: number, y: number, parentwidth: number, parenthieght: number, myRow?
) {
  x = Math.abs(x);
  const breakPointswidth = parentwidth / 12
	const breakPointsheight = parenthieght/15
  let col: number;
  switch (true) {
		case x >= breakPointswidth && x < breakPointswidth * 2:
			col = 1
			break
		case x >= breakPointswidth * 2 && x < breakPointswidth * 3:
			col = 2
			break
		case x >= breakPointswidth * 3 && x < breakPointswidth * 4:
			col = 3
			break
		case x >= breakPointswidth * 4 && x < breakPointswidth * 5:
			col = 4
			break
		case x >= breakPointswidth * 5 && x < breakPointswidth * 6:
			col = 5
			break
		case x >= breakPointswidth * 6 && x < breakPointswidth * 7:
			col = 6
			break
		case x >= breakPointswidth * 7 && x < breakPointswidth * 8:
			col = 7
			break
		case x >= breakPointswidth * 8 && x < breakPointswidth * 9:
			col = 8
			break
		case x >= breakPointswidth * 9 && x < breakPointswidth * 10:
			col = 9
			break
		case x >= breakPointswidth * 10 && x < breakPointswidth * 11:
			col = 10
			break
		case x >= breakPointswidth * 11 && x < breakPointswidth * 12:
			col = 11
			break
		case x >= breakPointswidth * 12:
			col = 11
			break
		default:
			col = 0

			break
	}
	let row: number = myRow !== undefined ? myRow : -1
	if (row === -1) {
		switch (true) {
			case y >= breakPointsheight && y < breakPointsheight * 2:
				row = 1
				break
			case y >= breakPointsheight * 2 && y < breakPointsheight * 3:
				row = 2
				break
			case y >= breakPointsheight * 3 && y < breakPointsheight * 4:
				row = 3
				break
			case y >= breakPointsheight * 4 && y < breakPointsheight * 5:
				row = 4
				break
			case y >= breakPointsheight * 5 && y < breakPointsheight * 6:
				row = 5
				break
			case y >= breakPointsheight * 6 && y < breakPointsheight * 7:
				row = 6
				break
			case y >= breakPointsheight * 7 && y < breakPointsheight * 8:
				row = 7
				break
			case y >= breakPointsheight * 8 && y < breakPointsheight * 9:
				row = 8
				break
			case y >= breakPointsheight * 9 && y < breakPointsheight * 10:
				row = 9
				break
			case y >= breakPointsheight * 10 && y < breakPointsheight * 11:
				row = 10
				break
			case y >= breakPointsheight * 11 && y < breakPointsheight * 12:
				row = 11
				break
			case y >= breakPointsheight * 12 && y<  breakPointsheight * 13 :
				row = 12
				break
			case y >= breakPointsheight * 13 && y<  breakPointsheight * 14 :
				row = 13
				break
			case y >= breakPointsheight * 14 && y<  breakPointsheight * 15 :
					row = 14
					break
			case y >= breakPointsheight * 15&& y<breakPointsheight*16:
					row = 15
					break
			case y >= breakPointsheight * 16 && y<breakPointsheight*17:
					row = 16
					break
			case y >= breakPointsheight * 17 && y<breakPointsheight*18:
					row = 17
					break
			case y >= breakPointsheight * 18 && y<breakPointsheight*19:
					row = 18
					break
			case y >=breakPointsheight*19:
					row=19				
					break
			default:
				row =  0
				break
		}
	}
  const breakpoints = {
    Xs: 12,
    sm: 12,
    md: 6,
    lg: Math.round(w / breakPointswidth),
    row: row,
    col: col,
    height: 1,
  };

  return breakpoints;
}

export function convertToCamelCaseGeneric(inputString) {
  const cleanedString = removeSpecialCharacters(inputString);
  return convertToCamelCase(cleanedString);
}

// basic css
export function getBasicStyles() {
  return `p-fieldset .p-fieldset {
        .p-fieldset-legend {
            background-color: transparent;
        }
        .p-toggleable-content .p-fieldset-content,
        .p-fieldset-content {
            background-color: transparent;
        }
    }
    `;
}

//local functions
function convertToCamelCase(inputString) {
  const words = inputString.split(' ');
  const camelCaseWords = words.map((word, index) => {
    if (index === 0) {
      return word.toLowerCase();
    }
    return word.charAt(0).toUpperCase() + word.slice(1);
  });
  return camelCaseWords.join('');
}

function removeSpecialCharacters(inputString) {
  return inputString.replace(/[^\w\s]/g, '');
}
