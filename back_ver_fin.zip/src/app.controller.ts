import {
  Controller,
  Post,
  Body,
  Res,
  Get,
  Delete,
  Query,
} from '@nestjs/common';
import { AppService } from './app.service';
import { generationFolderName, tokensToExtract } from './utils/constants';
const fs = require('fs');
const path = require('path');
import * as archiver from 'archiver';
import { getBasicStyles } from './utils/utilities';
import { ParserDTO } from './types/FigmaParser.models';
import { Response } from 'express';
import * as fsExtra from 'fs-extra'; // Use fsExtra for recursive deletion
const JSZip = require('jszip');

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}
  fileName: any;
  folderGeneName: any;
  globalOutput: any
  @Post()
  async generateDesignToCode(@Body() body: ParserDTO, @Res() res) {

    try {
      fsExtra.emptyDirSync('generationFolder');
      this.fileName = path.join(__dirname, '..', Date.now() + 'your_file.zip');  
      const zip = new JSZip();
      this.globalOutput = await this.appService.parse(
        body.fileId,
        tokensToExtract,
        body.token,
      );
      for (const output of this.globalOutput) {
        const folderName = output.template.featureName;
        this.folderGeneName = 'generationFolder/' + folderName;
  
        try {
          fsExtra.mkdirpSync(this.folderGeneName); // Create folders recursively
        } catch (error) {
          if (error.code !== 'EEXIST') {
            console.error('Error creating folder:', error);
            return;
          }
        }
  
        const jsonString = JSON.stringify(output.template, null, 2);
        const jsonFileName = output.template.title;
        let array = []
        Object.entries(output.globalHtml).forEach(([key, value]) => {
           const htmlFilePath = path.join(this.folderGeneName, `${key}.html`);
           array.push({htmlFilePath: htmlFilePath, key, value})
        });
        array.forEach((elem)=> {
          console.log(elem.htmlFilePath, elem.key)
          fs.writeFileSync(elem.htmlFilePath, elem.value, 'utf-8');
          zip.file(`${folderName}/${elem.key}.html`, fs.readFileSync(elem.htmlFilePath));
        })
        const jsonFilePath = path.join(this.folderGeneName, `/${jsonFileName}.json`);
        const scssFilePath = path.join(this.folderGeneName, `/${jsonFileName}.scss`);
  
        fs.writeFileSync(jsonFilePath, jsonString);
        fs.writeFileSync(scssFilePath, getBasicStyles());
        fs.writeFileSync(scssFilePath, output.css.text, { flag: 'a' });
  
        zip.file(`${folderName}/${jsonFileName}.json`, fs.readFileSync(jsonFilePath));
        zip.file(`${folderName}/${jsonFileName}.scss`, fs.readFileSync(scssFilePath));
        array = []
      }
      zip.generateNodeStream({ type: 'nodebuffer', streamFiles: true })
        .pipe(fs.createWriteStream(this.fileName))
        .on('finish', () => {
      this.globalOutput = undefined
          res.status(200).json({
            fileName: this.fileName,
            folderGeneName: this.folderGeneName,
          });
        });
    } catch (err) {
      res.status(500).send('errr');
    }
  }
  async readFileWithRetries(path, maxRetries) {
    let retries = 0;
    while (retries < maxRetries) {
      try {
        const data = await fs.promises.readFile(path, 'utf8');
        return data;
      } catch (error) {
        if (error.code === 'EPERM' && retries < maxRetries - 1) {
          console.error(
            `Permission denied. Retrying... (Attempt ${retries + 1})`,
          );
          retries++;
        } else {
          fs.unlink(path, (v) => console.log('err.message', v));
          console.error('error', error);
          return;
        }
      }
    }
    console.error('error');
    return;
  }
  deleteDirectoryRecursive(directoryPath) {
    if (fs.existsSync(directoryPath)) {
      fs.readdirSync(directoryPath).forEach((file) => {
        const filePath = path.join(directoryPath, file);
        if (fs.statSync(filePath).isDirectory()) {
          this.deleteDirectoryRecursive(filePath);
        } else {
          fs.unlinkSync(filePath);
        }
      });
      fs.rmdirSync(directoryPath);
    }
  }
  @Delete('delete')
  deleteFile(@Query() query, @Res() res) {
    const filePath = query.folderName;
    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
        const pathDir = path.join(__dirname, '..', 'generationFolder');
        this.deleteDirectoryRecursive(pathDir);
        res.status(200).json({ success: true });
      } catch (err) {
        throw new Error('something went wrong');
      }
    } else {
      console.log('Directory does not exist.');
    }
  }

  @Get('download')
  downloadGeneratedFiles(@Query() query, @Res() res) {
    try {
      const filePath = query.folder;
      if (fs.existsSync(filePath)) {
        res.attachment(filePath);
        res.sendFile(filePath);
        this.fileName = "";
        this.folderGeneName = ""
      } else {
        res.send('file not found');
      }
    } catch (err) {
      console.log(err);
    }
  }
}
