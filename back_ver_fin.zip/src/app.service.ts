import { Injectable } from '@nestjs/common';
import {
  convertToBreakpoints,
  convertToCamelCaseGeneric,
  generateUniqueName,
  multiplyColor,
} from './utils/utilities';
import * as uiStudioTemplates from './utils/ui-studio-templates';
import { Settings, Token, Tokens } from './types/FigmaParser.models';
import { defaultTokens, figmaApiBasePath } from './utils/constants';
import * as Figma from './types/FigmaApi';
// import fs from 'fs';
const fs = require('fs');
import { HttpService } from '@nestjs/axios';
import { AxiosError } from 'axios';
import { firstValueFrom } from 'rxjs';
import { catchError } from 'rxjs/operators';
const path = require('path');

@Injectable()
export class AppService {
  constructor(private httpClient: HttpService) {}

  private fileId: String;
  private tokens: Token[];

  public singleOutput: Tokens = {
    template: {},
    title: {},
    name: {},
    featureName: {},
    textfiled: {},
    textarea: {},
    radioBtn: {},
    button: {},
    btnLink: {},
    date: {},
    colors: {},
    comboBox: {},
    label: {},
    group: {},
    vgprogressbar: {},
    iconbtn: {},
  };
  // public globalOutput: Tokens[] = []
  public globalOutput: any[] = [];
  outputFile: any;

  /**
   * Trigger parse and apply template
   */
  parse = async (fileId: string, tokens: Token[], figmaToken): Promise<any> => {
    const globalOutputs = []
    this.fileId = fileId;
    this.tokens = tokens || defaultTokens;

    const document = await this.request(fileId, figmaToken);

    if (!document) {
      throw new Error('Error loading file');
    }
    const pageList = document['document'].children;

    pageList.forEach((page: Figma.Canvas) => {
      page.children.forEach((node) => {
        if (node.type === 'COMPONENT') {
          // const newOutput = { ...this.singleOutput }
          const featureName = convertToCamelCaseGeneric(page.name);
          

          const screenTemplateName = node.name;
          const screenJsonTemplate = uiStudioTemplates.screenTemplate(
            featureName,
            screenTemplateName,
          );

          let globalCustomComponentsHtml = {};
          let css = { text: '' };
          const parentwidth = node.absoluteBoundingBox.width;
          const parenthieght = node.absoluteBoundingBox.height;
          this.parseTree(
            node,
            screenJsonTemplate,
            css,
            globalCustomComponentsHtml,
            parentwidth,
            parenthieght,
          );
          globalOutputs.push({
            template: screenJsonTemplate,
            css: { ...css },
            globalHtml: { ...globalCustomComponentsHtml },
          });
        }
      });
    });
    return globalOutputs;
  };

  //Make an API request call
  ///
  async request(fileId, token): Promise<Figma.Document> {
    const { data } = await firstValueFrom(
      this.httpClient
        .get<Figma.Document>(`${figmaApiBasePath}files/${fileId}`, {
          headers: { 'X-Figma-Token': token },
        })
        .pipe(
          catchError((error: AxiosError) => {
            throw 'An error happened!';
          }),
        ),
    );
    return data;
  }

  private parseTree = (
    node: Readonly<
      Figma.Canvas | Figma.FrameBase | Figma.Node | Figma.Component
    >,
    outputFile: any,
    css: any,
    globalHtml,
    parenthieght: any,
    parentwidth: any,
  ): void => {
    const nameParts = node.name.split('-');

    const layer =
      node['children'] && node['children'].length > 0
        ? node['children'][0]
        : node;
    const role = nameParts[0];

    const compnentsNames = [
      'TextFilter',
      'iconButton',
      'ComboBox',
      'Button',
      'Searchable',
      'Label',
      'HR',
      'Group',
      'Block',
      'Date',
      'TextArea',
      'TextField',
      'Radio',
      'ButtonLink',
    ];

    //name + title
    if (node.name === 'screenName' && node.type === 'TEXT') {
      outputFile.name = layer['characters'];

      outputFile.title = layer['characters'];
    }
    // textFilter
    if (node.name === 'body') {
      node['children']
        .filter((child) => child.name === 'TextFilter' && child.type == 'FRAME')
        .forEach((textFilter) => {
          const styleName = `TextFilterStyle${generateUniqueName()} .p-inputtext`;
          const modifiedStyleName = styleName.replace('.p-inputtext', '');
          const x = textFilter.absoluteBoundingBox.x;
          const y = textFilter.absoluteBoundingBox.y;
          const w = textFilter.absoluteBoundingBox.width;
          const h = textFilter.absoluteBoundingBox.height;
          const row = this.getRow(
            node['children'],
            textFilter,
            'TextFiler',
            'FRAME',
          );
          const breakpoints = convertToBreakpoints(
            x,
            w,
            y,
            parentwidth,
            parenthieght,
            row,
          );
          const textFilterJsonTemplate: any =
            uiStudioTemplates.textFilterTemplate(
              textFilter.name,
              textFilter.backgroundColor ? modifiedStyleName : null,
              breakpoints,
            );
          if (
            !textFilter.backgroundColor &&
            !textFilter.cornerRadius &&
            !textFilter['children'][0].children[1].style.fontSize &&
            !textFilter['children'][0].children[1].style.fontWeight &&
            !textFilter['children'][0].children[1].fills[0].color
          ) {
            delete textFilterJsonTemplate.styleName;
          } else {
            css.text += uiStudioTemplates.getStyles({
              styleName: styleName,
              background: multiplyColor(textFilter.backgroundColor) + ';',
              color:
                multiplyColor(
                  textFilter.children[0].children[1].fills[0].color,
                ) + ';',
              fontsize:
                textFilter['children'][0].children[1].style.fontSize +
                'px' +
                ';',
              fontweight:
                textFilter['children'][0].children[1].style.fontWeight + ';',
              borderradius: textFilter.cornerRadius || '0' + 'px' + ';',
            });
          }
          outputFile.components.push(textFilterJsonTemplate);
        });
    }
    // Section
    if (node.name === 'Block' && node.type === 'FRAME') {
      const styleName = `SectionStyle${generateUniqueName()}`;
      const x = node.absoluteBoundingBox.x;
      const y = node.absoluteBoundingBox.y;
      const w = node.absoluteBoundingBox.width;
      const row = this.getRow(node['children'], node, 'Block', 'FRAME');
      const breakpoints = convertToBreakpoints(
        x,
        w,
        y,
        parentwidth,
        parenthieght,
        row,
      );
      const sectionJsonTemplate: any = uiStudioTemplates.sectionTemplate(
        node.name,
        node.backgroundColor ? styleName : null,
        breakpoints,
      );
      if (!node.backgroundColor) {
        delete sectionJsonTemplate.styleName;
      } else {
        css.text += uiStudioTemplates.getStyles({
          styleName,
          background: multiplyColor(node.backgroundColor) + ';',
        });
      }
      outputFile.components.push(sectionJsonTemplate);
    }
    //line
    if (node.name === 'body') {
      node['children']
        .filter((child) => child.name === 'HR' && child.type === 'VECTOR')
        .forEach((line) => {
          const styleName = `LineStyle${generateUniqueName()}`;
          const lineJsontemplate: any = uiStudioTemplates.lineTemplate(
            line.name,
            line.fills[0].color ? styleName : null,
          );
          if (!line.fills[0].color) {
            delete lineJsontemplate.styleName;
          } else {
            css.text += uiStudioTemplates.getStyles({
              styleName,
              color: multiplyColor(line['fills'][0].color) + ';',
            });
          }
          outputFile.components.push(lineJsontemplate);
        });
    }
    // Combobox
    if (node.name === 'Block' || node.name === 'body') {
      node['children']
        .filter((child) => child.name === 'ComboBox' && child.type == 'FRAME')
        .forEach((comboBox) => {
          const styleName = `ComboBoxStyle${generateUniqueName()} .p-dropdown`;
          const modifiedStyleName = styleName.replace('.p-dropdown', '');
          const x = comboBox.absoluteBoundingBox.x;
          const w = comboBox.absoluteBoundingBox.width;
          const h = comboBox.absoluteBoundingBox.height;
          const y = comboBox.absoluteBoundingBox.y;
          const row = this.getRow(
            node['children'],
            comboBox,
            'combobox',
            'FRAME',
          );
          const breakpoints = convertToBreakpoints(
            x,
            w,
            y,
            parentwidth,
            parenthieght,
            row,
          );

          const comboBoxJsonTemplte: any = uiStudioTemplates.comboBoxTemplate(
            comboBox.name,
            comboBox['children'][1].characters,
            comboBox['children'][1].fills[0].color ? modifiedStyleName : null,
            breakpoints,
          );
          if (
            !comboBox.backgroundColor &&
            !comboBox['children'][1].style.fontWeight &&
            !comboBox['children'][1].style.fontSize &&
            comboBox.cornerRadius
          ) {
            delete comboBoxJsonTemplte.styleName;
          } else {
            css.text += uiStudioTemplates.getStyles({
              styleName,
              background: multiplyColor(comboBox.backgroundColor) + ';',
              fontweight: comboBox['children'][1].style.fontWeight + ';',
              fontsize: comboBox['children'][1].style.fontSize + 'px' + ';',
              borderradius: comboBox.cornerRadius || '0' + 'px' + ';',
            });
          }
          const index = outputFile.components.findIndex(
            (key) => key.type === 'Block',
          );
          if (index !== -1) {
            outputFile.components[index].components.push(comboBoxJsonTemplte);
          } else {
            outputFile.components.push(comboBoxJsonTemplte);
          }
        });
    }
    // body btn
    if (node.name === 'body' || node.name === 'Block') {
      node['children']
        .filter((child) => child.name === 'Button' && child.type === 'FRAME')
        .forEach((button) => {
          const styleName = `ButtonStyle${generateUniqueName()} button`;
          const modifiedStyleName = styleName.replace(' button', '');
          const x = button.absoluteBoundingBox.x;
          const y = button.absoluteBoundingBox.y;
          const w = button.absoluteBoundingBox.width;
          const row = this.getRow(node['children'], button, 'button', 'FRAME');

          const breakpoints = convertToBreakpoints(
            x,
            w,
            y,
            parentwidth,
            parenthieght,
            row,
          );

          const buttonJsonTemplate: any = uiStudioTemplates.btnTemplate(
            button.name,
            button['children'][0].children[0].characters,
            button.backgroundColor ? modifiedStyleName : null,
            breakpoints,
          );
          if (
            !button.backgroundColor &&
            !button.children[0].children[0].fills[0].color &&
            !button.children[0].children[0].style.fontSize &&
            !button.children[0].children[0].style.fontWeight &&
            !button.cornerRadius
          ) {
            delete buttonJsonTemplate.styleName;
          } else {
            css.text += uiStudioTemplates.getStyles({
              styleName,
              background: multiplyColor(button.backgroundColor) + ';',
              color:
                multiplyColor(button.children[0].children[0].fills[0].color) +
                ';',
              fontsize:
                button.children[0].children[0].style.fontSize + 'px' + ';',
              fontweight: button.children[0].children[0].style.fontWeight + ';',
              borderradius: button.cornerRadius || '0' + 'px' + ';',
              //borderradius: textFilter.cornerRadius || '0' + "px" + ";",
            });
          }
          const index = outputFile.components.findIndex(
            (key) => key.type === 'Block',
          );
          if (index !== -1) {
            outputFile.components[index].components.push(buttonJsonTemplate);
          } else {
            outputFile.components.push(buttonJsonTemplate);
          }
        });
    }
    // icon btn
    if (node.name === 'body') {
      node['children']
        .filter(
          (child) => child.name === 'iconButton' && child.type === 'FRAME',
        )
        .forEach((iconbtn) => {
          const styleName = `iconButtonStyle${generateUniqueName()} button`;
          const modifiedStyleName = styleName.replace(' button', '');
          const x = iconbtn.absoluteBoundingBox.x;
          const y = iconbtn.absoluteBoundingBox.y;
          const w = iconbtn.absoluteBoundingBox.width;
          const h = iconbtn.absoluteBoundingBox.height;
          const row = this.getRow(
            node['children'],
            iconbtn,
            'iconbutton',
            'FRAME',
          );
          const breakpoints = convertToBreakpoints(
            x,
            w,
            y,
            parenthieght,
            parentwidth,
            row,
          );
          const iconBtnJsonTemplate: any = uiStudioTemplates.iconButtonTemplate(
            iconbtn.children[0].name,
            iconbtn.backgroundColor ? modifiedStyleName : null,
            breakpoints,
          );
          if (!iconbtn.backgroundColor && !iconbtn.cornerRadius) {
            delete iconBtnJsonTemplate.styleName;
          } else {
            css.text += uiStudioTemplates.getStyles({
              styleName,
              background: multiplyColor(iconbtn.backgroundColor) + ';',

              borderradius: iconbtn.cornerRadius + ';',
            });
          }
          outputFile.components.push(iconBtnJsonTemplate);
        });
    }
    //	Group
    if (node.name === 'Group' && node.type === 'FRAME') {
      const styleName = `GroupStyle${generateUniqueName()}`;
      const x = node.absoluteBoundingBox.x;
      const y = node.absoluteBoundingBox.y;
      const h = node.absoluteBoundingBox.height;
      const w = node.absoluteBoundingBox.width;
      const row = this.getRow(node['children'], node, 'group', 'FRAME');
      const breakpoints = convertToBreakpoints(
        x,
        w,
        y,
        parenthieght,
        parentwidth,
        row,
      );
      const groupJsonTemplate: any = uiStudioTemplates.groupTemplate(
        node.name,
        node.backgroundColor ? styleName : null,
        breakpoints,
      );
      if (!node.backgroundColor && !node['cornerRadius']) {
        delete groupJsonTemplate.styleName;
      } else {
        css.text += uiStudioTemplates.getStyles({
          styleName,
          background: multiplyColor(node.backgroundColor) + ';',
          borderradius: node['cornerRadius'] + 'px',
        });
      }
      outputFile.components.push(groupJsonTemplate);
    }
    // label
    if (
      node.name === 'Block' ||
      node.name === 'body' ||
      node.name === 'Group'
    ) {
      node['children']
        .filter((child) => child.name === 'Label' && child.type === 'TEXT')
        .forEach((label) => {
          const styleName = `labelStyle${generateUniqueName()} .label-title`;
          const modifiedStyleName = styleName.replace(' .label-title', '');
          const x = label.absoluteBoundingBox.x;
          const y = label.absoluteBoundingBox.y;
          const w = label.absoluteBoundingBox.width;
          const h = label.absoluteBoundingBox.height;
          const row = this.getRow(node['children'], label, 'label', 'TEXT');

          const breakpoints = convertToBreakpoints(
            x,
            w,
            y,
            parenthieght,
            parentwidth,
            row,
          );

          const labelJsontemplate: any = uiStudioTemplates.labelTemplate(
            label.name,
            label.characters,
            label.fills[0].color ? modifiedStyleName : null,
            breakpoints,
          );
          if (
            !label.fills[0].color &&
            !label.style.fontWeight &&
            !label.style.fontSize
          ) {
            delete labelJsontemplate.styleName;
          } else {
            css.text += uiStudioTemplates.getStyles({
              styleName,
              color: multiplyColor(label['fills'][0].color) + ';',
              fontweight: label.style.fontWeight + ';',
              fontsize: label.style.fontSize + 'px',
            });
          }
          const index = outputFile.components.findIndex(
            (key) => key.type === 'Group',
          );
          if (index !== -1) {
            outputFile.components[index].components.push(labelJsontemplate);
          } else {
            outputFile.components.push(labelJsontemplate);
          }
        });
    }

    // searchable
    // if (node.name === 'body') {
    //   node['children']
    //     .filter((child) => child.name === 'Searchable' && child.type == 'FRAME')
    //     .forEach((searchable) => {
    //       const styleName = `SearchableStyle${generateUniqueName()}`;
    //       const x = 800 + searchable.absoluteBoundingBox.x;
    //       const y = -390 + searchable.absoluteBoundingBox.y;
    //       const w = searchable.absoluteBoundingBox.width;
    //       const h = searchable.absoluteBoundingBox.height;
    //       const breakpoints = convertToBreakpoints(x, w, h, y);
    //       const searchableJsonTemplate: any =
    //         uiStudioTemplates.searchableTemplate(
    //           searchable.name,
    //           searchable['children'][1].characters,
    //           searchable.backgroundColor ? styleName : null,
    //           breakpoints,
    //         );
    //       if (
    //         !searchable.backgroundColor &&
    //         !searchable.cornerRadius &&
    //         !searchable['children'][0].children[1].style.fontSize &&
    //         !searchable['children'][0].children[1].style.fontWeight &&
    //         !searchable['children'][0].children[1].fills[0].color
    //       ) {
    //         delete searchableJsonTemplate.styleName;
    //       } else {
    //         css.text += uiStudioTemplates.getStyles({
    //           styleName: styleName,
    //           background: multiplyColor(searchable.backgroundColor) + ';',
    //           color:
    //             multiplyColor(
    //               searchable.children[0].children[1].fills[0].color,
    //             ) + ';',
    //           fontsize:
    //             searchable['children'][0].children[1].style.fontSize +
    //             'px' +
    //             ';',
    //           fontweight:
    //             searchable['children'][0].children[1].style.fontWeight + ';',
    //           borderradius: searchable.cornerRadius + 'px' + ';',
    //         });
    //       }
    //       outputFile.components.push(searchableJsonTemplate);
    //     });
    // }

    //footer btn
    if (node.name === 'footer') {
      node['children']
        .filter((child) => child.name === 'Button' && child.type === 'FRAME')
        .forEach((button) => {
          const buttonJsonTemplate: any = uiStudioTemplates.btnTemplate(
            button.name,
            button['children'][0].children[0].characters,
            button['children'][0].children[0].backgroundColor,
          );
          buttonJsonTemplate.properties.position = 'bottom';
          outputFile.actions.push(buttonJsonTemplate);
        });
    }

    //textfiled
    if (node.name === 'body') {
      node['children']
        .filter((child) => child.name === 'TextField' && child.type === 'FRAME')
        .forEach((textfiled) => {
          const textFiledJsonTemplate: any =
            uiStudioTemplates.textFieldTemplate(
              textfiled.name,
              textfiled['children'][0].characters,
            );

          outputFile.components.push(textFiledJsonTemplate);
        });
    }
    //textarea
    if (node.name === 'body') {
      node['children']
        .filter((child) => child.name === 'TextArea' && child.type === 'FRAME')
        .forEach((textarea) => {
          const textAreaJsonTemplate: any = uiStudioTemplates.textAreaTemplate(
            textarea.name,
            textarea['children'][0].characters,
          );
          outputFile.components.push(textAreaJsonTemplate);
        });
    }
    //Radio
    if (node.name === 'body') {
      node['children']
        .filter((child) => child.name === 'Radio' && child.type === 'FRAME')
        .forEach((radioBtn) => {
          const radioBtnJsonTemplate: any = uiStudioTemplates.radioBtnTemplate(
            radioBtn.name,
            radioBtn['children'][0].characters,
          );

          outputFile.components.push(radioBtnJsonTemplate);
        });
    }

    // ButtonLink
    if (node.name === 'body') {
      node['children']
        .filter(
          (child) => child.name === 'ButtonLink' && child.type === 'FRAME',
        )
        .forEach((btnLink) => {
          const linkBtnJsonTemplate: any = uiStudioTemplates.linkBtnTemplate(
            btnLink.name,
            btnLink['children'][0].children[0].characters,
          );
          outputFile.components.push(linkBtnJsonTemplate);
        });
    }
    // Date
    if (node.name === "body") {
			node["children"]
				.filter((child) => child.name === "Date" && child.type === "FRAME")
				.forEach((date) => {
					const x = date.absoluteBoundingBox.x
					const y = date.absoluteBoundingBox.y
					const w = date.absoluteBoundingBox.width
					const row = this.getRow(node["children"], date, "date", "FRAME")
					const breakpoints = convertToBreakpoints(x, w, y, parentwidth, parenthieght, row)
					const dateJsonTemplate: any = uiStudioTemplates.dateTemplate(date.name, date["children"][0].children[0].characters, breakpoints)
					outputFile.components.push(dateJsonTemplate)
				})
		}

    // Custom to HTML
    if (node.name === 'body') {
      const htmlCustomComponentName = 'CustomComponent' + generateUniqueName();
      const htmlContent = node['children']
        .filter((child) => compnentsNames.includes(child.name) === false)
        .map((customComp) => {
          const x = customComp.absoluteBoundingBox.x;
          const y = customComp.absoluteBoundingBox.y;
          const w = customComp.absoluteBoundingBox.width;
          const row = this.getRow(
            node['children'],
            customComp,
            'custom',
            'FRAME',
          );
          const breakpoints = convertToBreakpoints(
            x,
            w,
            y,
            parentwidth,
            parenthieght,
            row,
          );
          const customCompJsonTemplate: any =
            uiStudioTemplates.customCompTemplate(
              breakpoints,
              htmlCustomComponentName,
            );

          outputFile.components.push(
            // uiStudioTemplates.customCompTemplate(customCompJsonTemplate),
            customCompJsonTemplate,
          );

          return this.convertToFigma(customComp);
        })
        .join('');
      // const htmlFilePath = path.join(
      //   __dirname,
      //   '..',
      //   outputFile.featureName,
      //   htmlCustomComponentName + '.html',
      // );
      // fs.writeFileSync(htmlFilePath, htmlContent, 'utf-8');
      // globalHtml.push({ htmlCustomComponentName: htmlContent });
      globalHtml[htmlCustomComponentName] = htmlContent;
      // console.log(globalHtml)
    }

    if (node['children']) {
      node['children'].forEach((child) => {
        this.parseTree(
          child,
          outputFile,
          css,
          globalHtml,
          parentwidth,
          parenthieght,
        );
      });
    }
  };
  getRow(parent, me, name, type) {
    const y = me.absoluteBoundingBox.y;
    const rows = parent

      .filter((child) => child.name === name && child.type === type)
      .map((elem) => elem.absoluteBoundingBox.y)
      .sort((a, b) => a - b);
    const rowsWithoutDuplicates = [...new Set(rows)];
    const whereAmI = rowsWithoutDuplicates.indexOf(y);

    return whereAmI;
  }

  // convertToFigma(jsonData) {
  //   if (jsonData.children) {
  //     const htmlElements = jsonData.children.map((child) => {
  //       let rgbaColor = '';
  //       if (child.fills.length > 0) {
  //         rgbaColor = `rgba(${Math.round(
  //           child.fills[0].color.r * 255,
  //         )}, ${Math.round(child.fills[0].color.g * 255)}, ${Math.round(
  //           child.fills[0].color.b * 255,
  //         )}, ${child.fills[0].color.a})`;
  //       }
  //       let element;
  //       if (
  //         child.type === 'FRAME' ||
  //         child.type === 'BOOLEAN_OPERATION' ||
  //         child.type === 'GROUP' ||
  //         child.type === 'INSTANCE' ||
  //         child.type === 'VECTOR' ||
  //         child.type === 'RECTANGLE'
  //       ) {
  //         const childHtml = this.convertToFigma(child);

  //         element = `<div id="${child.id}" style=" width:${
  //           child.absoluteBoundingBox.width
  //         }px; height:${child.absoluteBoundingBox.height}px;background-color: ${
  //           rgbaColor.length > 0 ? rgbaColor : 'transparent'
  //         } ;border-radius:${child.cornerRadius}px";>

	//  				${childHtml}
	//  						   </div>`;
  //       } else {
  //         element = `<${child.type.toLowerCase()} id="${
  //           child.id
  //         }" style="color: ${
  //           rgbaColor.length > 0 ? rgbaColor : 'transparent'
  //         }" >
	//  							 ${child.characters ? child.characters : ''}
	//  							 ${child ? this.convertToFigma(child) : ''}
	//  						   </${child.type.toLowerCase()}>`;
  //       }

  //       return element;
  //     });

  //     return htmlElements.join('');
  //   } else {
  //     return '';
  //   }
  // }
  convertToFigma(jsonData) {
		if (jsonData.children) {
		  const htmlElements = jsonData.children.map((child) => {
			let rgbaColor = '';
			if (child.fills.length > 0) {
			  rgbaColor = `rgba(${Math.round(
				child.fills[0].color.r * 255
			  )}, ${Math.round(child.fills[0].color.g * 255)}, ${Math.round(
				child.fills[0].color.b * 255
			  )}, ${child.fills[0].color.a})`;
			}
			let displayStyle = '';
			if (
			  child.type === 'FRAME' ||
			  child.type === 'BOOLEAN_OPERATION' ||
			  child.type === 'GROUP' ||
			  child.type === 'INSTANCE' ||
			  child.type === 'VECTOR' ||
			  child.type === 'RECTANGLE'
			) {
			  const childHtml = this.convertToFigma(child);
			  displayStyle = 'inline-flex';
			  
			  // Check if child elements are all inline
			  const allInline = childHtml.includes('display: inline-flex;');
			  if (!allInline) {
				displayStyle = 'block';
			  }
	  
			  return `<div id="${child.id}" style="width:${
				child.absoluteBoundingBox.width
			  }px; height:${child.absoluteBoundingBox.height}px;background-color: ${
				rgbaColor.length > 0 ? rgbaColor : 'transparent'
			  };border-radius:${child.cornerRadius ? child.cornerRadius : '0'}px; display: ${displayStyle};
			  flex-direction: column;
			  gap: 18px;">
				${childHtml}
			  </div>`;
			} else {
			  displayStyle = 'inline-flex';
	  
			  return `<${child.type.toLowerCase()} id="${
				child.id
			  }" style="color: ${rgbaColor.length > 0 ? rgbaColor : 'transparent'};
				font-family:${child.style.fontFamily} ;
				font-size:${child.style.fontSize}px;
				font-weight:${child.style.fontWeight};
				display: ${displayStyle};
				line-height: ${child.style.lineHeightPx}px;
        letter-spacing: ${child.style.letterSpacing}px ">
				${child.characters ? child.characters : ''}
				${child ? this.convertToFigma(child) : ''}
			  </${child.type.toLowerCase()}>`;
			}
		  });
	  
		  return htmlElements.join('');
		} else {
		  return '';
		}
	  }

  eraseOutPut() {
    this.outputFile = undefined;
    this.globalOutput = [];
  }
}
