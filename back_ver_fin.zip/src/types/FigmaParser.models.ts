export type Token =
  | 'iconbtn'
  | 'vgprogressbar'
  | 'group'
  | 'label'
  | 'comboBox'
  | 'colors'
  | 'date'
  | 'btnLink'
  | 'name'
  | 'featureName'
  | 'title'
  | 'template'
  | 'textfiled'
  | 'button'
  | 'textarea'
  | 'radioBtn';

export type Tokens = {
  [key in Token]: Object;
};

export interface Settings {
  token: string;
}
export interface ParserDTO {
  token: string;
  fileId: string;
}
